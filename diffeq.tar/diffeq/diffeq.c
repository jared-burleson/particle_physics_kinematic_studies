#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "diffeq.h"
#define RKF54_MAX_DECREASE 14
#define RKF54_TEST_INCREASE 0.2

int rk2(int order,void (*func)(int n,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]) {
  double x,xhalfinc,xnext,*ymid;
  double *k1,*k2;   /*Runge-Kutta slope values*/
  int j;

  ymid = (double *) malloc(order * sizeof(double));
  k1 = (double *) malloc(order * sizeof(double));
  k2 = (double *) malloc(order * sizeof(double));
  xstop = xstop + (xinc * 0.5);
  xhalfinc = xinc * 0.5;
  x = xstart;
  while (1) {
    printf("%.8g ",x);   /*output independent variables*/
    for (j = 0; j < order; j++) printf("%.8g ",y[j]);   /*output state values*/
    putchar('\n');
    xnext = x + xinc;
    if (((xinc > 0.0) && (xnext > xstop)) || ((xinc < 0.0) && (xnext < xstop))) break;
    (*func)(order,x,y,k1);   /*calculate RK2 (Improved polygon method) algorithm step*/
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xhalfinc * k1[j]);
    (*func)(order,x + xhalfinc,ymid,k2);
    for (j = 0; j < order; j++) y[j] += xinc * k2[j];
    x = xnext;
  }
  free(ymid);
  free(k1);
  free(k2);
  return(0);
}

int rk4(int order,void (*func)(int n,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]) {
  double x,xhalfinc,xnext,*ymid;
  double *k1,*k2,*k3,*k4;   /*Runge-Kutta slope values*/
  int j;

  ymid = (double *) malloc(order * sizeof(double));
  k1 = (double *) malloc(order * sizeof(double));
  k2 = (double *) malloc(order * sizeof(double));
  k3 = (double *) malloc(order * sizeof(double));
  k4 = (double *) malloc(order * sizeof(double));
  xstop = xstop + (xinc * 0.5);
  xhalfinc = xinc * 0.5;
  x = xstart;
  while (1) {
    printf("%.8g ",x);   /*output independent variable*/
    for (j = 0; j < order; j++) printf("%.8g ",y[j]);   /*output state values*/
    putchar('\n');
    xnext = x + xinc;
    if (((xinc > 0.0) && (xnext > xstop)) || ((xinc < 0.0) && (xnext < xstop))) break;
    (*func)(order,x,y,k1);   /*calculate RK4 algorithm step*/
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xhalfinc * k1[j]);
    (*func)(order,x + xhalfinc,ymid,k2);
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xhalfinc * k2[j]);
    (*func)(order,x + xhalfinc,ymid,k3);
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xinc * k3[j]);
    (*func)(order,x + xinc,ymid,k4);
    for (j = 0; j < order; j++) y[j] += xinc * (k1[j] + (2.0 * k2[j]) + (2.0 * k3[j]) + k4[j]) / 6.0;
    x = xnext;
  }
  free(ymid);
  free(k1);
  free(k2);
  free(k3);
  free(k4);
  return(0);
}

int rk4_quiet(int order,void (*func)(int n,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]) {
  double x,xhalfinc,xnext,*ymid;
  double *k1,*k2,*k3,*k4;   /*Runge-Kutta slope values*/
  int j;

  ymid = (double *) malloc(order * sizeof(double));
  k1 = (double *) malloc(order * sizeof(double));
  k2 = (double *) malloc(order * sizeof(double));
  k3 = (double *) malloc(order * sizeof(double));
  k4 = (double *) malloc(order * sizeof(double));
  xstop = xstop + (xinc * 0.5);
  xhalfinc = xinc * 0.5;
  x = xstart;
  while (1) {
    xnext = x + xinc;
    if (((xinc > 0.0) && (xnext > xstop)) || ((xinc < 0.0) && (xnext < xstop))) break;
    (*func)(order,x,y,k1);   /*calculate RK4 algorithm step*/
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xhalfinc * k1[j]);
    (*func)(order,x + xhalfinc,ymid,k2);
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xhalfinc * k2[j]);
    (*func)(order,x + xhalfinc,ymid,k3);
    for (j = 0; j < order; j++) ymid[j] = y[j] + (xinc * k3[j]);
    (*func)(order,x + xinc,ymid,k4);
    for (j = 0; j < order; j++) y[j] += xinc * (k1[j] + (2.0 * k2[j]) + (2.0 * k3[j]) + k4[j]) / 6.0;
    x = xnext;
  }
  free(ymid);
  free(k1);
  free(k2);
  free(k3);
  free(k4);
  return(0);
}

int rkf54_adaptive(int order,void (*func)(int n,double x,double y[],double yp[]),double xstart,double xstop,double xincmax,double y[],double tol[]) {
  double x,xinc,error,*ytemp,*y4;
  double *k1,*k2,*k3,*k4,*k5,*k6;   /*Runge-Kutta-Fehlberg slope values*/
  double *errormax,*errormin,*errorsum,n_steps;
  int j,dec,decflag,incflag,decmax;
  double rkf54_c20 = 0.25;
  double rkf54_c21 = 0.25;
  double rkf54_c30 = 0.375;
  double rkf54_c31 = 0.09375;
  double rkf54_c32 = 0.28125;
  double rkf54_c40 = 12.0 / 13.0;
  double rkf54_c41 = 1932.0 / 2197.0;
  double rkf54_c42 = -7200.0 / 2197.0;
  double rkf54_c43 = 7296.0 / 2197.0;
  double rkf54_c51 = 439.0 / 216.0;
  double rkf54_c52 = -8.0;
  double rkf54_c53 = 3680.0 / 513.0;
  double rkf54_c54 = -845.0 / 4104.0;
  double rkf54_c60 = 0.5;
  double rkf54_c61 = -8.0 / 27.0;
  double rkf54_c62 = 2.0;
  double rkf54_c63 = -3544.0 / 2565.0;
  double rkf54_c64 = 1859.0 / 4104.0;
  double rkf54_c65 = -0.275;
  double rkf54_a1 = 25.0 / 216.0;
  double rkf54_a3 = 1408.0 / 2565.0;
  double rkf54_a4 = 2197.0 / 4104.0;
  double rkf54_a5 = -0.2;
  double rkf54_b1 = 16.0 / 135.0;
  double rkf54_b3 = 6656.0 / 12825.0;
  double rkf54_b4 = 28561.0 / 56430.0;
  double rkf54_b5 = -0.18;
  double rkf54_b6 = 2.0 / 55.0;

  ytemp = (double *) malloc(order * sizeof(double));
  y4 = (double *) malloc(order * sizeof(double));
  k1 = (double *) malloc(order * sizeof(double));
  k2 = (double *) malloc(order * sizeof(double));
  k3 = (double *) malloc(order * sizeof(double));
  k4 = (double *) malloc(order * sizeof(double));
  k5 = (double *) malloc(order * sizeof(double));
  k6 = (double *) malloc(order * sizeof(double));
  errormax = (double *) malloc(order * sizeof(double));
  errormin = (double *) malloc(order * sizeof(double));
  errorsum = (double *) malloc(order * sizeof(double));
  for (j = 0; j < order; j++) {
    errormax[j] = 0.0;
    errormin[j] = 1.0e300;
    errorsum[j] = 0.0;
  }
  dec = 0;
  decmax = 0;
  xinc = xincmax;
  n_steps = 0.0;
  xstop = xstop - (xincmax * pow(0.5,(double) (RKF54_MAX_DECREASE + 1)));
  x = xstart;
  printf("%.8g %.8g ",x,xinc);   /*output independent variable and step size*/
  for (j = 0; j < order; j++) printf("%.8g ",y[j]);   /*output state values*/
  putchar('\n');
  while (((xinc > 0.0) && (x < xstop)) || ((xinc < 0.0) && (x > xstop))) {
    (*func)(order,x,y,k1);   /*calculate RKF45 algorithm step*/
    for (j = 0; j < order; j++) {
      k1[j] *= xinc;
      ytemp[j] = y[j] + (rkf54_c21 * k1[j]);
    }
    (*func)(order,x + rkf54_c20 * xinc,ytemp,k2);
    for (j = 0; j < order; j++) {
      k2[j] *= xinc;
      ytemp[j] = y[j] + (rkf54_c31 * k1[j] + rkf54_c32 * k2[j]);
    }
    (*func)(order,x + rkf54_c30 * xinc,ytemp,k3);
    for (j = 0; j < order; j++) {
      k3[j] *= xinc;
      ytemp[j] = y[j] + (rkf54_c41 * k1[j] + rkf54_c42 * k2[j] + rkf54_c43 * k3[j]);
    }
    (*func)(order,x + rkf54_c40 * xinc,ytemp,k4);
    for (j = 0; j < order; j++) {
      k4[j] *= xinc;
      ytemp[j] = y[j] + (rkf54_c51 * k1[j] + rkf54_c52 * k2[j] + rkf54_c53 * k3[j] + rkf54_c54 * k4[j]);
    }
    (*func)(order,x + xinc,ytemp,k5);
    for (j = 0; j < order; j++) {
      k5[j] *= xinc;
      ytemp[j] = y[j] + (rkf54_c61 * k1[j] + rkf54_c62 * k2[j] + rkf54_c63 * k3[j] + rkf54_c64 * k4[j] + rkf54_c65 * k5[j]);
    }
    (*func)(order,x + rkf54_c60 * xinc,ytemp,k6);
    decflag = 0;
    incflag = 1;
    for (j = 0; j < order; j++) {
      k6[j] *= xinc;
      y4[j] = y[j] + (rkf54_a1 * k1[j] + rkf54_a3 * k3[j] + rkf54_a4 * k4[j] + rkf54_a5 * k5[j]);
      y[j] = y[j] + (rkf54_b1 * k1[j] + rkf54_b3 * k3[j] + rkf54_b4 * k4[j] + rkf54_b5 * k5[j] + rkf54_b6 * k6[j]);
      error = fabs(y[j] - y4[j]);
      if (error > tol[j]) decflag = 1;
      if (error > RKF54_TEST_INCREASE * tol[j]) incflag = 0;
    }
    if (decflag && (dec >= RKF54_MAX_DECREASE)) {
      decflag = 0;
      fprintf(stderr,"Warning: Minimum x step reached at x=%.8g\n",x);
    }
    if (incflag && (dec <= 0)) {
      incflag = 0;
    }
    if (!decflag) {
      for (j = 0; j < order; j++) {
        error = fabs(y[j] - y4[j]);
        if (error > errormax[j]) errormax[j] = error;
        if (error < errormin[j]) errormin[j] = error;
        errorsum[j] += error;
      }
      x = x + xinc;
      printf("%.8g %.8g ",x,xinc);   /*output independent variable and step size*/
      for (j = 0; j < order; j++) printf("%.8g ",y[j]);   /*output state values*/
      putchar('\n');
      n_steps += 1.0;
    }
    if (decflag) {
      dec++;
      if (dec > decmax) decmax = dec;
      xinc = xincmax * pow(0.5,(double) dec);
    }
    else if (incflag) {
      dec--;
      xinc = xincmax * pow(0.5,(double) dec);
    }
  }
  fprintf(stderr,"State variable     Minimum error     Maximum error     Mean error\n");
  for (j = 0; j < order; j++) {
    fprintf(stderr,"     %4d        %15.8g   %15.8g   %15.8g\n",j,errormin[j],errormax[j],errorsum[j] / n_steps);
  }
  fprintf(stderr,"Total number of steps = %.0f\n",n_steps);
  fprintf(stderr,"Maximum step size decrease exponent = %d\n",decmax);
  free(ytemp);
  free(y4);
  free(k1);
  free(k2);
  free(k3);
  free(k4);
  free(k5);
  free(k6);
  free(errormax);
  free(errormin);
  free(errorsum);
  return(0);
}
