int rk2(int order,void (*func)(int i,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]);
int rk4(int order,void (*func)(int i,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]);
int rk4_quiet(int order,void (*func)(int i,double x,double y[],double yp[]),double xstart,double xstop,double xinc,double y[]);
int rkf54_adaptive(int order,void (*func)(int i,double x,double y[],double yp[]),double xstart,double xstop,double xincmax,double y[],double tol[]);
