#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "diffeq.h"
#include "constants.h"

/*
  Simple pendulum
  State variable 0 is displacement angle
  State variable 1 is angular velocity
  length = pendulum length in meters
*/

double length;

void pendulum(int n,double x,double y[2],double yp[2]) {
  yp[0] = ;   /*Complete this statement */
  yp[1] = ;   /*Complete this statement */
}

int main(int argc,char *argv[]) {
  double xstop,xinc,y[2];

  if (argc != 6) {
    fprintf(stderr,"%s <length> <init y0> <init y1> <tstop> <tinc>\n",argv[0]);
    exit(1);
  }
  length = atof(argv[1]);
  y[0] = atof(argv[2]);
  y[1] = atof(argv[3]);
  xstop = atof(argv[4]);
  xinc = atof(argv[5]);
  rk4(2,pendulum,0.0,xstop,xinc,y);
  exit(0);
}
